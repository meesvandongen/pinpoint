# gitvfs-cms

A Git-backed content management system. Describe your content with [zod](https://zod.dev) schemas. `gitvfs-cms` reads and writes it as markdown with YAML frontmatter, JSON or YAML files in a GitHub or GitLab repository, through [gitvfs](../gitvfs). Every save is a commit. The React editor generates its forms with [AutoForm](https://autoform.vantezzen.io/) and shows a live preview.

## Install

```sh
pnpm add gitvfs gitvfs-cms zod
# for the editor UI
pnpm add react react-dom react-hook-form @hookform/resolvers
# for OpenID Connect sign-in
pnpm add oidc-spa
```

## Quick start

```tsx
import { z } from 'zod'
import { GitVFS } from 'gitvfs'
import { github } from 'gitvfs/providers/github'
import { createCms, defineCollection, defineSingleton, markdown } from 'gitvfs-cms'
import { CmsApp } from 'gitvfs-cms/react'
import 'gitvfs-cms/styles.css'

const posts = defineCollection({
  name: 'posts',
  label: 'Posts',
  folder: 'content/posts',
  schema: z.object({
    title: z.string().min(1),
    date: z.coerce.date().optional(),
    draft: z.boolean().default(false),
    body: z.string().check(markdown()).default(''),
  }),
})

const site = defineSingleton({
  name: 'site',
  path: 'data/site.json',
  schema: z.object({ title: z.string() }),
})

const cms = createCms({
  fs: new GitVFS({ repository: github({ token }).repository('acme/site'), branch: 'main' }),
  collections: [posts],
  singletons: [site],
})

export const Admin = () => <CmsApp cms={cms} title="Acme" />
```

## Entry points

| Import | Contents | Needs |
| --- | --- | --- |
| `gitvfs-cms` | `defineCollection`, `defineSingleton`, `createCms` / `GitCms`, document parsing, field helpers | `gitvfs`, `zod` |
| `gitvfs-cms/react` | `CmsApp`, `DocumentEditor`, `ContentForm`, previews, AutoForm components | `react`, `react-dom`, `react-hook-form`, `@hookform/resolvers` |
| `gitvfs-cms/oidc` | `createOidcSession`, `oidcTokenProvider`, `gitlabOidc` | `oidc-spa` |
| `gitvfs-cms/codemirror` | `CodeMirrorField`, `CodeMirrorEditor`: CodeMirror 6 for code fields | `@codemirror/{state,view,commands,language,lang-javascript,lang-json,lang-yaml,lang-css,lang-html}`, `@lezer/highlight` |
| `gitvfs-cms/mermaid` | `MermaidField`, `renderMermaid`: live Mermaid previews | `mermaid` |
| `gitvfs-cms/styles.css` | Default editor theme (`gcms-*` classes, CSS custom properties) | |

## Highlights

- **Collections** (a folder of entries) and **singletons** (one file), in markdown, JSON or YAML.
- **Faithful saves:** keys the schema does not know are kept, and existing keys keep their order, so diffs stay small.
- **Validation** against the schema before anything is committed. Stored files that do not match still open, with the issues listed.
- **Editor** with text, number, checkbox, date, select, list, group, textarea and markdown fields (the markdown field has a toolbar), map fields for a point, a point with a radius, a line, a polygon and several (labelled) markers, with optional address search (built-in `nominatimGeocoder`, or any service), date and time (with time zone handling), time, slider, money, duration and phone fields, read-only and hidden fields, a graph field: a node-and-edge editor with a canvas, auto layout and a keyboard-friendly list view, and code fields with highlighting, indentation, line numbers and JSON/YAML syntax checks. Lists of objects can be edited as a spreadsheet-like table (paste from spreadsheets, copy as CSV), and nested menus or page hierarchies as an outline with keyboard and drag-and-drop reordering. Optional entries add a CodeMirror editor (`gitvfs-cms/codemirror`) and live Mermaid diagrams (`gitvfs-cms/mermaid`), in fields and in the markdown preview.
- **Scheduling fields:** date ranges, weekly opening hours with breaks, hours past midnight and holidays (`isOpenAt`, schema.org and OpenStreetMap output), and recurring dates as RFC 5545 rules with a built-in, dependency-free expander.
- **References** between entries (`reference()`, `references()`), stored as slugs and picked from a searchable list; the editor warns about references to missing entries and before deleting or renaming an entry that others reference.
- **Preview** in an iframe sandboxed without scripts, so repository content cannot reach the user's token. A **Source** tab shows the exact file that will be committed.
- **Changes** (`changes: true`): edit on branches, see changed fields marked (with revert) and both versions previewed before and after or as a source diff, then open a pull request and publish it from the editor.
- **OIDC sign-in** via [oidc-spa](https://www.oidc-spa.dev/), with a GitLab preset whose OAuth tokens work directly against the GitLab API.

Full documentation: [`packages/docs`](../docs), whose `/admin` page edits the docs with this package.

## Develop

```sh
pnpm --filter gitvfs-cms dev    # playground with an in-memory repository at http://localhost:3001
pnpm --filter gitvfs-cms test
pnpm --filter gitvfs-cms build
```
